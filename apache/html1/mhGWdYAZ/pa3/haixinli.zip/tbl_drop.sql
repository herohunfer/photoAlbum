# drop all tables

# firstly drop the existing tables
drop table User, Album,AlbumAccess,Contain,Photo;

